Com esta ferramenta, você
         pode fazer o bot Whatsapp facilmente,                              sem o incômodo, de colocar comandos
Você quer continuar?[y/n]
